import java.util.ArrayList;
import java.util.List;

/**
 *	Deck of cards
 *
 *	@author	
 *	@since	
 */
public class DeckOfCards
{
	private SinglyLinkedList<Card> deck;	// the deck of cards
	
	/** constructor */
	public DeckOfCards() { }
	
	/**	Add the Card to the bottom of the deck
	 *	@param c		the card to add
	 */
	public void add(Card c) { }
	
	/**	Removes the card from the top of the deck
	 *	@return		the card removed from the top of the deck; null if deck is empty
	 */
	public Card draw() { return null; }
	
	/**	Clear the deck of cards */
	public void clear()	{ }
	
	/**	Clear deck and fills with standard 52 card deck */
	public void fill() { }
	
	/**	@return		true if deck is empty; false otherwise */
	public boolean isEmpty() { return false; }
	
	/**	Randomizes the order of the cards in the deck
	 *	This method must be SinglyLinkedList-based (do not use arrays or ArrayList)
	 */
	public void shuffle() { }
	
	/**	@return		the size of the deck */
	public int size() { return 0; }
	
	/**	print the deck */
	public void print()
	{
		for (int a = 0; a < deck.size(); a++)
			System.out.print(deck.get(a) + "; ");
		System.out.println();
	}
	
	/***************************************************************************/
	/************************** Testing methods ********************************/
	/***************************************************************************/
	public static void main(String[] args)
	{
		DeckOfCards doc = new DeckOfCards();
		doc.fill();
		doc.add(new Card(Rank.ACE, Suit.SPADES));
		System.out.println("Deck size = " + doc.size());
		doc.print();
		System.out.println();
		doc.shuffle();
		System.out.println("Deck size = " + doc.size());
		doc.print();
		System.out.println();
	}
}