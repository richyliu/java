/**
 *	The suit of the cards
 */
public enum Suit
{
	CLUBS, DIAMONDS, HEARTS, SPADES;
}