/**
 *	The Game of War
 *	(Description)
 *
 *	Requires ListNode and Prompt classes
 *	
 *	@author	
 *	@since	
 */
public class GameOfWar
{
	/*	Fields  */
	
	/**	Constructor */
	public GameOfWar() { }
	
	
	/**	Prints the introduction to the game */
	public void printIntroduction()
	{
		System.out.println("   ______                        ____  ____   _       __");
		System.out.println("  / ____/___ _____ ___  ___     / __ \\/ __/  | |     / /___ ______");
		System.out.println(" / / __/ __ `/ __ `__ \\/ _ \\   / / / / /_    | | /| / / __ `/ ___/");
		System.out.println("/ /_/ / /_/ / / / / / /  __/  / /_/ / __/    | |/ |/ / /_/ / /");
		System.out.println("\\____/\\__,_/_/ /_/ /_/\\___/   \\____/_/       |__/|__/\\__,_/_/"); 
		System.out.println("\nWelcome to the Game of War");
	}
		
}